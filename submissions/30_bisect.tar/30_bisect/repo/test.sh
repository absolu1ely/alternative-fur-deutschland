#!/bin/sh
[ "$(cat behavior.txt)" = good ]
