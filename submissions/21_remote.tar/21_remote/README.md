Работайте в repo/. remote.git — локальный учебный remote.
